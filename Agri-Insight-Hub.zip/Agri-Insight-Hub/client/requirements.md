## Packages
recharts | Data visualization for history and analytics
framer-motion | Smooth page transitions and UI animations
lucide-react | Beautiful icons
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
API requires credentials: "include" for all requests due to Replit Auth.
Disease detection uses multipart/form-data.
